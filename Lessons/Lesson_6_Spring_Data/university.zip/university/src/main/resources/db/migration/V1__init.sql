create table students (id bigserial primary key, name varchar(255), score int);
insert into students (name, score) values
('Bob', 80),
('John', 70),
('Jack', 90);