package ru.geekbrains.spring.context;

import java.util.List;

public interface StudentRepository {
    List<Student> getStudents();
}
