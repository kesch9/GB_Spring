package com.flamexander.hibernate.validation;

public interface FullRule {
}
