package com.flamexander.hibernate.validation;

public interface ShortRule {
}
