package ru.geekbrains.first.spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
